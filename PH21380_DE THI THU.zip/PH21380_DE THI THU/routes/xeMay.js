const express = require('express');
const router = express.Router();
const XeMay = require('../models/XeMay');

// Hiển thị danh sách
router.get('/', async (req, res) => {
  try {
    const xeMays = await XeMay.find();
    res.json(xeMays);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Xem chi tiết 1 bản ghi
router.get('/:id', getXeMay, (req, res) => {
  res.json(res.xeMay);
});

// Thêm mới bản ghi
router.post('/', async (req, res) => {
  const xeMay = new XeMay({
    ten_xe: req.body.ten_xe,
    mau_sac: req.body.mau_sac,
    gia_ban: req.body.gia_ban,
    mo_ta: req.body.mo_ta,
    hinh_anh: req.body.hinh_anh
  });
  try {
    const newXeMay = await xeMay.save();
    res.status(201).json(newXeMay);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Middleware để lấy xe máy theo ID
async function getXeMay(req, res, next) {
  let xeMay;
  try {
    xeMay = await XeMay.findById(req.params.id);
    if (xeMay == null) {
      return res.status(404).json({ message: 'Cannot find xe may' });
    }
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
  res.xeMay = xeMay;
  next();
}

module.exports = router;
