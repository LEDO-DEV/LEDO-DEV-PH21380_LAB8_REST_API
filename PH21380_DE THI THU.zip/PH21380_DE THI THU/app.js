const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

mongoose.connect('mongodb://localhost:27017/xemay_ph21380', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on('error', (error) => console.error(error));
db.once('open', () => console.log('Đã Kết Nối Với Database MongoDB'));

const xeMayRouter = require('./routes/xeMay');
app.use('/xemay', xeMayRouter);

app.listen(3000, () => console.log('Server Hiện Tại Đang Hoạt Động'));

//http://localhost:3000/xemay